﻿#************************************************
# DC_DSRegEntries.ps1
# Version 1.0
# Date: 2009-2019
# Author: + Walter Eder (waltere@microsoft.com)
# Description: Collects Directory Services Registry Entries
# Called from: TS_AutoAddCommands_DOM.ps1, TS_AutoAddCommands_NET.ps1
#*******************************************************

function InsertRegHeader(
	[string] $RegHeader="",
	[string]$OutputFile)
{
	if($RegHeader -ne "")
	{
		$RegHeader | Out-File -FilePath $OutputFile -Append -Encoding Default
		"=" * ($RegHeader.Length) | Out-File -FilePath $OutputFile -Append -Encoding Default
	}
}

Import-LocalizedData -BindingVariable InboxCommandStrings
	
Write-DiagProgress -Activity $InboxCommandStrings.ID_DSRegentriesActivity -Status $InboxCommandStrings.ID_DSRegentriesStatus

$OutputFile = $ComputerName + "_reg_DS_REGENTRIES.txt"
$fileDescription = "Directory Services Registry Entries"

InsertRegHeader -OutputFile $OutputFile -RegHeader "Authentication registry Key - Credential Providers and Filters, LogonUI (Vista/2008 only)"
RegQuery -RegistryKeys "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "LSA registry key and subkeys"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Control\Lsa" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "Winlogon registry key and subkeys"
RegQuery -RegistryKeys "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "Winlogon registry key in the user's profile"
RegQuery -RegistryKeys "HKCU\Software\Microsoft\Windows NT\CurrentVersion\Winlogon" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "LanManServer and LanManWorkstation Parameters Registry Keys"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Services\lanmanworkstation\parameters","HKLM\SYSTEM\CurrentControlSet\Services\lanmanserver\parameters","HKLM\Software\Microsoft\Windows\Windows Error Reporting\FullLiveKernelReports" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "Netlogon\Parameters registry Key"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Services\Netlogon\parameters" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "NTDS\Parameters registry Key"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Services\NTDS\parameters" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "Product Options registry key and subkeys"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Control\ProductOptions" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "RPC registry key and subkeys"
RegQuery -RegistryKeys "HKLM\SOFTWARE\Microsoft\Rpc" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "System's and user's NetCache registry key where Offline Files settings are stored"
RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\NetCache","HKCU\Software\Microsoft\Windows\CurrentVersion\NetCache" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "Registry keys showing scripts assigned to the user via Group Policy"
RegQuery -RegistryKeys "HKCU\Software\Microsoft\Windows\CurrentVersion\Group Policy\Scripts" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "Group Policy assigned 'Run at user logon' programs - programs assigned to run at user logon"
RegQuery -RegistryKeys "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\Run" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "RUN registry keys for the current user"
RegQuery -RegistryKeys "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run","HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce","HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnceEx" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "RUN registry keys for the local machine"
RegQuery -RegistryKeys "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run","HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce","HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnceEx" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "TCPIP\Parameters registry key"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "W32Time registry key and subkeys"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Services\w32time" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "Winreg registry key and subkeys"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Control\SecurePipeServers\winreg" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile  -RegHeader "ProfileList registry key listing local profiles"
RegQuery -RegistryKeys "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $true
InsertRegHeader -OutputFile $OutputFile  -RegHeader "SecurityProviders\SCHANNEL registry key and subkeys"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $false

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}

# SIG # Begin signature block
# MIIjlQYJKoZIhvcNAQcCoIIjhjCCI4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDgV+ozBO9T1b7/
# zXvFIQFmBNPU9QJne237wl6cHZMcDqCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVajCCFWYCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgnBLKNQpD
# Egb0Y6orus6icKgtwgZug7LH7YyE3GK8I6wwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBADevPfdVdD8Em1QyHWKQ1y4FMWUZDa8pRByUSzRwFryVBGRizGmAUaiZ
# aEysForMEwgzTq6a4jEcoNlzaG05RPEJJBEEDK51MfF91DrPNvTJLZIjs27nCL2P
# qy/bVPWqrZbOjHT/qTzmupF/SX3VLSuZB/sIXQJ0QgQ7v48HXq8Byqlzm+Tl+m1k
# w6qpa3tBrhfCsydH442auxvNYvVojtKX9usXHkNbOZ0h3ZRLay3gXNdwlrBmlq8G
# Lqpah2T6YxrwYfxcKy1aSgSoEcFB65G2umsoJhLVpClh7hMDt9a9LapvhFEsAyMZ
# jTisxJktGHfd0xb7gZQlhQg/WopV4w+hghL+MIIS+gYKKwYBBAGCNwMDATGCEuow
# ghLmBgkqhkiG9w0BBwKgghLXMIIS0wIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYL
# KoZIhvcNAQkQAQSgggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgWH09qSKHZh4vkli8qeZTn1bXlUwQUoLMO7gNtCRPIK0CBmGDCPNa
# ShgTMjAyMTExMTExNjUzNDMuMTcxWjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjpGQzQxLTRCRDQtRDIyMDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCDk0wggT5MIID4aADAgECAhMzAAABQCMZ1l7elSQxAAAAAAFAMA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIw
# MTAxNTE3MjgyNloXDTIyMDExMjE3MjgyNlowgdIxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RkM0MS00
# QkQ0LUQyMjAxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCufWszcerVL03TPxH5gqpm
# 7bnKSTk6VPxOy7C10FbIMJEWgBKT18HqyIKiUWFcGHJ6PhzfIjA3RTIlYE5MCMe1
# 44hiN8KnHnf2tuAEjn8FMe0L6pwFPt+0+SdO1Cfz2U05yk/vR+5hVkuhCwOcuMbH
# G1b95V7BHlDQjWZZB8nLnE596WTk5aPPdhXgcq2rIhHMll39HNxjzDqqbOhI2xgh
# 2+WJPZ55BlvJhN0lCxGjMgpMwsIlQF9WOjDZ8kwO3MMH1cQ51+E9bO9Q5p1iCqqH
# SWyUBHs1X3QUWZmBlYBGsbyPtmdWcLkw5c5L80jnxLjzJyy6DSk3Y0YsuTZhaPEL
# AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQUNUMcLiZ3RiCOjNKqdWz454QtDmcwHwYD
# VR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGlt
# U3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEF
# BQcDCDANBgkqhkiG9w0BAQsFAAOCAQEAYwxSraBC4IL3CvhiEhJ8/Khto1hXc6/h
# jBaxJ8jP+PXFo31O8sAHYHE+LYK1FuBsFR/jyfTvJF5kifC7avy/Aug0bZO1jN7L
# TUNHKOOw2iIcX1S5EsXIpkKGQoLej2vQ7LbHRhiNSkPFUKFnmrlwB/DzzjA/SJRx
# icooafx4nSfCmvvOv9OW74c6NcNP0LvnhpLgpQU2bwPuLC69ZbNI5WXtcxZ27zYG
# edOYHuzY5x/cjhp0bN2LFDlnHFrfM4C8rOtX7QdxVAhjdJAn0/OMNGXMK+IxOHED
# wVQhEvcWdiq9yFaQShnjDxLsWwZY2VctZDt8cxveXiCO54fI7inq1TCCBnEwggRZ
# oAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1
# MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ
# 1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP
# 8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRh
# Z5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39
# dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2
# iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGj
# ggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB
# /wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFv
# s+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5
# U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFS
# AK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1V
# ry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6
# f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35j
# WSUPei45V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHa
# sFAeb73x4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLN
# HfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4
# sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHX
# odLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUe
# CLraNtvTX4/edIhJEqGCAtcwggJAAgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjpGQzQxLTRCRDQtRDIyMDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAQqXmHvITpjsyl+YykRtDOQlyUVOggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUF
# AAIFAOU3aiAwIhgPMjAyMTExMTExODA4MzJaGA8yMDIxMTExMjE4MDgzMlowdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA5TdqIAIBADAKAgEAAgIO7wIB/zAHAgEAAgIR
# dzAKAgUA5Ti7oAIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBANEyD5Ljo9OQ
# SWXH6IHTDCTITSyNr8EZKXoanwHFhGnSBciAXIHmbeZcwwlqaoeK8yp5GTyXexIE
# xobyFbrdHl1wWVAfcRR9rnOnWx7R0oXpHgReDLdwHLySbSrsQ63ofwwGM/S5XEuK
# vlErjLYXNIKHIZt8CY6YPtFDCASWrRrAMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFAIxnWXt6VJDEAAAAAAUAwDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQgHmONgWpxtTsjKG8W0RSMbJYK+T6whRTDZDY4vwAK2cowgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCAvNrC16szSpFwk7/Ny8lPt2j/JynxFmxFJ
# Oqq2AgiXgzCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABQCMZ1l7elSQxAAAAAAFAMCIEIBBMG02OYr9XqrlepsjPw+b55xQrKrger77b
# WRAMxNnzMA0GCSqGSIb3DQEBCwUABIIBAEIjuKYYk4iGsjqMvbCWg++BRuHy2FvP
# USjjVCSirQZbOwRe5jcMsm3FwYkXpoc+mC9Tj9hDh79BjH6wJGyrxHF4LO9n0Eqa
# cPpStM9V5PRObVYKVopZGXYzPWQoQ3wqzQbsmXHb9PSWsu633zQT11AcTAquMTCJ
# Gx5k/z2kAXh+8pwT3aGK5ihTSGanUuvZdG6S4ogA6yNBp8FEcWhHEHkwdAIJfn9o
# bHwToB51Slt4JbXCKBgQF+v2XtejnPCKgxFo1rtzG6zwxZ3VrRcbk5fSnWEfjsWh
# hc44YVIIzLivSI899u0+ZmgLGTAP1U8IV83UZoSlIFzfuT0FRlGDQco=
# SIG # End signature block
