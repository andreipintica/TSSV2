#************************************************
# DC_Firewall-Component.ps1
# Version 1.0
# Version 1.1: Altered the runPS function correctly a column width issue.
# Date: 2009, 2014, 2020/waltere: add NetworkIsolation
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about the Windows Firewall.
# Called from: Main Networking Diag
#*******************************************************

param(
		[switch]$before,
		[switch]$after
	)

	
Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSFirewall -Status $ScriptVariable.ID_CTSFirewallDescription

# detect OS version and SKU
$wmiOSVersion = Get-CimInstance -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber


function RunNetSH ([string]$NetSHCommandToExecute="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSFirewall -Status "netsh $NetSHCommandToExecute"
	$NetSHCommandToExecuteLength = $NetSHCommandToExecute.Length + 6
	"-" * ($NetSHCommandToExecuteLength)	| Out-File -FilePath $outputFile -append
	"netsh $NetSHCommandToExecute"			| Out-File -FilePath $outputFile -append
	"-" * ($NetSHCommandToExecuteLength)	| Out-File -FilePath $outputFile -append
	$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + " >> $outputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
}


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
}


$sectionDescription = "Firewall"


#Handle suffix of file name
	if ($before)
	{
		$suffix = "_BEFORE"
	}
	elseif ($after)
	{
		$suffix = "_AFTER"
	}
	else
	{
		$suffix = ""
	}


#W8/WS2012+
if ($bn -gt 9000)
{	
	"[info]: Firewall-Component W8/WS2012+"  | WriteTo-StdOut 

	$outputFile= $Computername + "_Firewall_info_pscmdlets" + $suffix + ".TXT"
	"========================================"			| Out-File -FilePath $OutputFile -append
	"Firewall Powershell Cmdlets"						| Out-File -FilePath $OutputFile -append
	"========================================"			| Out-File -FilePath $OutputFile -append
	"Overview"											| Out-File -FilePath $OutputFile -append
	"----------------------------------------"			| Out-File -FilePath $OutputFile -append
	"Firewall Powershell Cmdlets"						| Out-File -FilePath $OutputFile -append
	"   1. Show-NetIPsecRule -PolicyStore ActiveStore"	| Out-File -FilePath $OutputFile -append
	"   2. Get-NetIPsecMainModeSA"						| Out-File -FilePath $OutputFile -append
	"   3. Get-NetIPsecQuickModeSA"						| Out-File -FilePath $OutputFile -append
	"   4. Get-NetFirewallProfile"						| Out-File -FilePath $OutputFile -append
	"   5. Get-NetFirewallRule"							| Out-File -FilePath $OutputFile -append
	"   6. Show-NetFirewallRule"						| Out-File -FilePath $OutputFile -append
	"========================================"			| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"========================================"			| Out-File -FilePath $OutputFile -append
	"Firewall Powershell Cmdlets"						| Out-File -FilePath $OutputFile -append
	"========================================"			| Out-File -FilePath $OutputFile -append
	runPS "Show-NetIPsecRule -PolicyStore ActiveStore"		# W8/WS2012, W8.1/WS2012R2	# fl
	runPS "Get-NetIPsecMainModeSA"							# W8/WS2012, W8.1/WS2012R2	# fl
	runPS "Get-NetIPsecQuickModeSA"							# W8/WS2012, W8.1/WS2012R2	# fl				
	runPS "Get-NetFirewallProfile"							# W8/WS2012, W8.1/WS2012R2	# fl
	runPS "Get-NetFirewallRule"								# W8/WS2012, W8.1/WS2012R2	# fl
	runPS "Show-NetFirewallRule"							# W8/WS2012, W8.1/WS2012R2	# fl

	CollectFiles -filesToCollect $outputFile -fileDescription "Firewall Information PS cmdlets" -SectionDescription $sectionDescription
}


#WV/WS2008+
if ($bn -gt 6000)
{
	"[info]: Firewall-Component WV/WS2008+"  | WriteTo-StdOut 

	#----------Netsh
	$outputFile = $ComputerName + "_Firewall_netsh_advfirewall" + $suffix + ".TXT"
	"========================================"			| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Output"					| Out-File -FilePath $OutputFile -append
	"========================================"			| Out-File -FilePath $OutputFile -append
	"Overview"											| Out-File -FilePath $OutputFile -append
	"----------------------------------------"			| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Output"					| Out-File -FilePath $OutputFile -append
	"   1. netsh advfirewall show allprofiles"			| Out-File -FilePath $OutputFile -append
	"   2. netsh advfirewall show allprofiles state"	| Out-File -FilePath $OutputFile -append
	"   3. netsh advfirewall show currentprofile"		| Out-File -FilePath $OutputFile -append
	"   4. netsh advfirewall show domainprofile"		| Out-File -FilePath $OutputFile -append
	"   5. netsh advfirewall show global"				| Out-File -FilePath $OutputFile -append
	"   6. netsh advfirewall show privateprofile"		| Out-File -FilePath $OutputFile -append
	"   7. netsh advfirewall show publicprofile"		| Out-File -FilePath $OutputFile -append
	"   8. netsh advfirewall show store"				| Out-File -FilePath $OutputFile -append
	"========================================"			| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"========================================"			| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Output"					| Out-File -FilePath $OutputFile -append
	"========================================"			| Out-File -FilePath $OutputFile -append
	RunNetSH -NetSHCommandToExecute "advfirewall show allprofiles"
	RunNetSH -NetSHCommandToExecute "advfirewall show allprofiles state"
	RunNetSH -NetSHCommandToExecute "advfirewall show currentprofile"
	RunNetSH -NetSHCommandToExecute "advfirewall show domainprofile"
	RunNetSH -NetSHCommandToExecute "advfirewall show global"
	RunNetSH -NetSHCommandToExecute "advfirewall show privateprofile"
	RunNetSH -NetSHCommandToExecute "advfirewall show publicprofile"
	RunNetSH -NetSHCommandToExecute "advfirewall show store"
	CollectFiles -filesToCollect $outputFile -fileDescription "Firewall Advfirewall" -SectionDescription $sectionDescription


	#-----WFAS export
	$filesToCollect = $ComputerName + "_Firewall_netsh_advfirewall-export" + $suffix + ".wfw"
	$commandToRun = "netsh advfirewall export " +  $filesToCollect
	RunCMD -CommandToRun $commandToRun -filesToCollect $filesToCollect -fileDescription "Firewall Export" -sectionDescription $sectionDescription 

	#-----WFAS ConSec rules (all)
	$outputFile = $ComputerName + "_Firewall_netsh_advfirewall-consec-rules" + $suffix + ".TXT"
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall ConSec Rules Output"					| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Overview"															| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall ConSec Rules Output"					| Out-File -FilePath $OutputFile -append
	"   1. netsh advfirewall consec show rule all any dynamic verbose"	| Out-File -FilePath $OutputFile -append
	"   2. netsh advfirewall consec show rule all any static verbose"	| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall ConSec Rules Output"					| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	# 3/5/2013: Through feedback from Markus Sarcletti, this command has been removed because it is an invalid command:
	#   "advfirewall consec show rule name=all"
	RunNetSH -NetSHCommandToExecute "advfirewall consec show rule all any dynamic verbose"
	RunNetSH -NetSHCommandToExecute "advfirewall consec show rule all any static verbose"
	CollectFiles -filesToCollect $outputFile -fileDescription "Advfirewall ConSec Rules" -SectionDescription $sectionDescription

	
	#-----WFAS ConSec rules (active)
	# 3/5/2013: Through feedback from Markus Sarcletti, adding active ConSec rules
	$outputFile = $ComputerName + "_Firewall_netsh_advfirewall-consec-rules-active" + $suffix + ".TXT"
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall ConSec Rules (ACTIVE)"					| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Overview"															| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall ConSec Rules (ACTIVE)"					| Out-File -FilePath $OutputFile -append
	"   1. netsh advfirewall monitor show consec verbose"				| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall ConSec Rules (ACTIVE)"					| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	RunNetSH -NetSHCommandToExecute "advfirewall monitor show consec verbose"
	CollectFiles -filesToCollect $outputFile -fileDescription "Advfirewall ConSec Rules" -SectionDescription $sectionDescription

	
	#-----WFAS Firewall rules (all)
	$outputFile = $ComputerName + "_Firewall_netsh_advfirewall-firewall-rules" + $suffix + ".TXT"
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Firewall Rules"							| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Overview"															| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Firewall Rules"							| Out-File -FilePath $OutputFile -append
	"   1. netsh advfirewall monitor show consec verbose"				| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Firewall Rules"							| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	RunNetSH -NetSHCommandToExecute "advfirewall firewall show rule name=all"
	CollectFiles -filesToCollect $outputFile -fileDescription "Advfirewall Firewall Rules" -SectionDescription $sectionDescription

	
	#-----WFAS Firewall rules all (active)
	# 3/5/2013: Through feedback from Markus Sarcletti, adding active Firewall Rules
	$outputFile = $ComputerName + "_Firewall_netsh_advfirewall-firewall-rules-active" + $suffix + ".TXT"
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Firewall Rules (ACTIVE)"				| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Overview"															| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Firewall Rules (ACTIVE)"				| Out-File -FilePath $OutputFile -append
	"   1. netsh advfirewall monitor show firewall verbose"				| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Firewall Rules (ACTIVE)"				| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	RunNetSH -NetSHCommandToExecute "advfirewall monitor show firewall verbose"
	CollectFiles -filesToCollect $outputFile -fileDescription "Advfirewall Firewall Rules" -SectionDescription $sectionDescription	

	
	
	#-----Netsh WFP	

	#-----Netsh WFP show netevents file=
	$outputFile = $ComputerName + "_Firewall_netsh_wfp-show-netevents" + $suffix + ".XML"
	$commandToRun = "netsh wfp show netevents file= " +  $outputFile
	RunCMD -CommandToRun $commandToRun -filesToCollect $outputFile -fileDescription "Netsh WFP Show Netevents" -sectionDescription $sectionDescription 
	
	#-----Netsh WFP show BoottimePolicy file=
	$outputFile = $ComputerName + "_Firewall_netsh_wfp-show-boottimepolicy" + $suffix + ".XML"
	$commandToRun = "netsh wfp show boottimepolicy file= " +  $outputFile
	RunCMD -CommandToRun $commandToRun -filesToCollect $outputFile -fileDescription "Netsh WFP Show BootTimePolicy" -sectionDescription $sectionDescription 

	#-----Netsh wfp show Filters file=
	$outputFile = $ComputerName + "_Firewall_netsh_wfp-show-filters" + $suffix + ".XML"
	$commandToRun = "netsh wfp show filters file= " +  $outputFile
	RunCMD -CommandToRun $commandToRun -filesToCollect $outputFile -fileDescription "Netsh WFP Show Filters" -sectionDescription $sectionDescription 
	
	#-----Netsh wfp show Options optionsfor=keywords
	$outputFile = $ComputerName + "_Firewall_netsh_wfp-show-options" + $suffix + ".TXT"
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh WFP Show Options"									| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Overview"															| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh WFP Show Options"									| Out-File -FilePath $OutputFile -append
	"   1. netsh wfp show options optionsfor=keywords"					| Out-File -FilePath $OutputFile -append
	"   2. netsh wfp show options optionsfor=netevents"					| Out-File -FilePath $OutputFile -append
	"   3. netsh wfp show options optionsfor=txnwatchdog"				| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh WFP Show Options"									| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	RunNetSH -NetSHCommandToExecute "wfp show options optionsfor=keywords"
	RunNetSH -NetSHCommandToExecute "wfp show options optionsfor=netevents"
	RunNetSH -NetSHCommandToExecute "wfp show options optionsfor=txnwatchdog"
	CollectFiles -filesToCollect $outputFile -fileDescription "Netsh WFP Show Options" -SectionDescription $sectionDescription

	
	#-----Netsh wfp show Security netevents
	$outputFile = $ComputerName + "_Firewall_netsh_wfp-show-security-netevents" + $suffix + ".TXT"
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh WFP Show Security Netevents"						| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Overview"															| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh WFP Show Security Netevents"						| Out-File -FilePath $OutputFile -append
	"   1. netsh wfp show security netevents"							| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh WFP Show Security Netevents"						| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	RunNetSH -NetSHCommandToExecute "wfp show security netevents"
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	CollectFiles -filesToCollect $outputFile -fileDescription "Netsh WFP Show Security NetEvents" -SectionDescription $sectionDescription






	#-----Netsh wfp show State file=
	$outputFile = $ComputerName + "_Firewall_netsh_wfp-show-state" + $suffix + ".XML"
	$commandToRun = "netsh wfp show state file= " +  $outputFile
	RunCMD -CommandToRun $commandToRun -filesToCollect $outputFile -fileDescription "Netsh WFP Show State" -sectionDescription $sectionDescription 
	
	#-----Netsh wfp show Sysports file=
	$outputFile = $ComputerName + "_Firewall_netsh_wfp-show-sysports" + $suffix + ".XML"
	$commandToRun = "netsh wfp show sysports file= " +  $outputFile
	RunCMD -CommandToRun $commandToRun -filesToCollect $outputFile -fileDescription "Netsh WFP Show Sysports" -sectionDescription $sectionDescription 



	#----------Netsh
	$outputFile = $ComputerName + "_Firewall_netsh_firewall.TXT"	
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh Firewall"											| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Overview"															| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh Firewall"											| Out-File -FilePath $OutputFile -append
	"   1. netsh firewall show allowedprogram"							| Out-File -FilePath $OutputFile -append
	"   2. netsh firewall show config"									| Out-File -FilePath $OutputFile -append
	"   3. netsh firewall show currentprofile"							| Out-File -FilePath $OutputFile -append
	"   4. netsh firewall show icmpsetting"								| Out-File -FilePath $OutputFile -append
	"   5. netsh firewall show logging"									| Out-File -FilePath $OutputFile -append
	"   6. netsh firewall show multicastbroadcastresponse"				| Out-File -FilePath $OutputFile -append
	"   7. netsh firewall show notifications"							| Out-File -FilePath $OutputFile -append
	"   8. netsh firewall show opmode"									| Out-File -FilePath $OutputFile -append
	"   9. netsh firewall show portopening"								| Out-File -FilePath $OutputFile -append
	"  10. netsh firewall show service"									| Out-File -FilePath $OutputFile -append
	"  11. netsh firewall show state"									| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	RunNetSH -NetSHCommandToExecute "firewall show allowedprogram"
	RunNetSH -NetSHCommandToExecute "firewall show config"
	RunNetSH -NetSHCommandToExecute "firewall show currentprofile"
	RunNetSH -NetSHCommandToExecute "firewall show icmpsetting"
	RunNetSH -NetSHCommandToExecute "firewall show logging"
	RunNetSH -NetSHCommandToExecute "firewall show multicastbroadcastresponse"
	RunNetSH -NetSHCommandToExecute "firewall show notifications"
	RunNetSH -NetSHCommandToExecute "firewall show opmode"
	RunNetSH -NetSHCommandToExecute "firewall show portopening"
	RunNetSH -NetSHCommandToExecute "firewall show service"
	RunNetSH -NetSHCommandToExecute "firewall show state"
	CollectFiles -filesToCollect $outputFile -fileDescription "Firewall" -SectionDescription $sectionDescription


	
	#----------Registry
	$outputFile= $Computername + "_Firewall_reg_" + $suffix + ".TXT"
	$CurrentVersionKeys =	"HKLM\Software\Policies\Microsoft\WindowsFirewall",
							"HKLM\SYSTEM\CurrentControlSet\Services\BFE",
							"HKLM\SYSTEM\CurrentControlSet\Services\IKEEXT",
							"HKLM\SYSTEM\CurrentControlSet\Services\MpsSvc",
							"HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess",
							"HKLM\Software\Policies\Microsoft\Windows\NetworkIsolation"
	$sectionDescription = "Firewall"
	RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -outputFile $outputFile -fileDescription "Firewall Registry Keys" -SectionDescription $sectionDescription


	#----------EventLogs
	if ( ($suffix -eq "") -or ($suffix -eq "_AFTER") )
	{
		#----------WFAS Event Logs
		$sectionDescription = "Firewall EventLogs"
		#WFAS CSR
		$EventLogNames = "Microsoft-Windows-Windows Firewall With Advanced Security/ConnectionSecurity"
		$Prefix = ""
		$Suffix = "_evt_"
		.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix

		#WFAS CSR Verbose
		$EventLogNames = "Microsoft-Windows-Windows Firewall With Advanced Security/ConnectionSecurityVerbose"
		$Prefix = ""
		$Suffix = "_evt_"
		.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix

		#WFAS FW
		$EventLogNames = "Microsoft-Windows-Windows Firewall With Advanced Security/Firewall"
		$Prefix = ""
		$Suffix = "_evt_"
		.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix

		#WFAS FW Verbose
		$EventLogNames = "Microsoft-Windows-Windows Firewall With Advanced Security/FirewallVerbose"
		$Prefix = ""
		$Suffix = "_evt_"
		.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
	}
	
} 
#Windows Server 2003
else
{
	"[info]: Firewall-Component XP/WS2003"  | WriteTo-StdOut 
	#----------Registry
	$outputFile= $Computername + "_Firewall_reg_.TXT"
	$CurrentVersionKeys =	"HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall",
							"HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess"
	$sectionDescription = "Firewall"
	RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -outputFile $outputFile -fileDescription "Firewall Registry Keys" -SectionDescription $sectionDescription
	
	#----------Netsh
	$outputFile = $ComputerName + "_Firewall_netsh.TXT"
	RunNetSH -NetSHCommandToExecute "firewall show allowedprogram"
	RunNetSH -NetSHCommandToExecute "firewall show config"
	RunNetSH -NetSHCommandToExecute "firewall show currentprofile"
	RunNetSH -NetSHCommandToExecute "firewall show icmpsetting"
	RunNetSH -NetSHCommandToExecute "firewall show logging"
	RunNetSH -NetSHCommandToExecute "firewall show multicastbroadcastresponse"
	RunNetSH -NetSHCommandToExecute "firewall show notifications"
	RunNetSH -NetSHCommandToExecute "firewall show opmode"
	RunNetSH -NetSHCommandToExecute "firewall show portopening"
	RunNetSH -NetSHCommandToExecute "firewall show service"
	RunNetSH -NetSHCommandToExecute "firewall show state"
	CollectFiles -filesToCollect $outputFile -fileDescription "Firewall" -SectionDescription $sectionDescription
}



# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAxHnJ7kET3Yg27
# 5z9TwFyWO/3Kt12HCUAIZtFWguoQeqCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgTijvtAiu
# lw5DlSYLmm+NE84Hjg3HvYohmoh3BXWSuNYwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAFCtkYec03rCTW7JABbAGg/4V2XPmRVm3wRlbxwwIwY4hGIy6lIRQIOL
# I8Wl4La6EVhDx7c1WMzigP+ZD4ndWyVOOwwH8xrjRIpx0JivvB0h/kCjuNRK51BJ
# dTIQvzx0pgohf7SYAqxsih+jKhlElmdxwJiPyGq0ZUxwd0oRKQQKbLU3/FpiS6fY
# l8ZgRnOcGBjVn089/ZBYT//2h++BbyIg6rxtkCdlOfnGlMxi2dYd8x3oqzAyiI61
# TS5a/E8AHxVvO2yuwZoyiFQa0qeNcma9prA8s9h0KdiWHsDl4JLeIZGyO2doA3Nb
# ICu8PoFp8eQ7Ic+WRxhy+XXUBM592uWhghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgsggSkAJTWRiD+5ELQeyLr4s5DwuPdwUbgzAVe5eMnnkCBmGB8A0Q
# LxgTMjAyMTExMTExNjUzMzQuMjc2WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3
# N0YtRTM1Ni01QkFFMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFenSnHX4cFoeoAAAAAAV4wDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE5WhcNMjIwNDExMTkwMjE5WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3N0YtRTM1Ni01QkFF
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAmtMjg5B6GfegqnbO6HpY/ZmJv8PHD+ys
# t57JNv153s9f58uDvMEDTKXqK8XafqVq4YfxbsQHBE8S/tkJJfBeBhnoYZofxpT4
# 6sNcBtzgFdM7lecsbBJtrJ71Hb65Ad0ImZoy3P+UQFZQrnG8eiPRNStc5l1n++/t
# OoxYDiHUBPXD8kFHiQe1XWLwpZ2VD51lf+A0ekDvYigug6akiZsZHNwZDhnYrOrh
# 4wH3CNoVFXUkX/DPWEsUiMa2VTd4aNEGIEQRUjtQQwxK8jisr4J8sAhmdQu7tLOU
# h+pJTdHSlI1RqHClZ0KIHp8rMir3hn73zzyahC6j3lEA+bMdBbUwjQIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFKpyfLoN3UvlVMIQAJ7OVHjV+B8rMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAH8h/FmExiQEypGZeeH9WK3ht/HKKgCWvscnVcNIdMi9
# HAMPU8avS6lkT++usj9A3/VaLq8NwqacnavtePqlZk5mpz0Gn64G+k9q6W57iy27
# dOopNz0W7YrmJty2kXigc99n4gp4KGin4yT2Ds3mWUfO/RoIOJozTDZoBPeuPdAd
# BLyKOdDn+qG3PCjUChSdXXLa6tbBflod1TNqh4Amu+d/Z57z0p/jJyOPJp80lJSn
# +ppcGVuMy73S825smy11LE62/BzF54c/plphtOXZw6VrhyiSI9T4FSMhkD+38hl9
# ihrMwaYG0tYUll0L0thZaYsuw0nZbbWqR5JKkQDDimYwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3N0YtRTM1Ni01
# QkFFMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQBWSY9X/yFlVL0XNu2hfbHdnbFjKqCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5TejBTAiGA8y
# MDIxMTExMTE4MTExN1oYDzIwMjExMTEyMTgxMTE3WjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDlN6MFAgEAMAoCAQACAh3fAgH/MAcCAQACAhFyMAoCBQDlOPSFAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAxVxDoMDffsH6dhlLg27cadDZ0u08
# b3hcPRrc4tQLyHLLNcf87UdIKyJl5FAEj3QiScbcFGcjJlgoD4NQJMTTnaNOqcKv
# xf8CplhQCXOllJWZl2WMsS4FvNKx2+XBbtaF8lHkR3bIk0lTgoEcaT1YVZr/v5Au
# IsO53Rw+1s05/rAxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAV6dKcdfhwWh6gAAAAABXjANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCAzco4y
# HBk4lKq0bwhDV3+Y5qqqfyZNNoD3KpiJf5NzKDCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIH7lhOyU1JeO4H7mZANMpGQzumuR7CFed69eku/xEtPiMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFenSnHX4cFoeoA
# AAAAAV4wIgQgDv5rcYpYecV7XG+04htmJ0mViE8lWWlIpUnwA/k2MYMwDQYJKoZI
# hvcNAQELBQAEggEAArulGkE+Nn5QVEAndrAs/hx7jXsg4sCUq/nOOC+e4XI/9fgz
# heqK4waYtrnHSqbFUCRqc6jRRq4l3/1plc9of112YrlBY72TLJgtlgqcOMYx5Dzk
# nWbPGHRl6nHFvpjH1visMnwfrCk3PEWCmrb4pGk2WaDkahZrL0tzCDfID0/pqHAw
# yfMiY1suVQ/kKxbfoM2RXkmN1modBgBG3E5dY7jx0XTymv4oopVLa9UpOUD7UUWK
# vwyIHilvKNujq6xzJcDYhz9S/xdXHt08ECs5GYLqNGJA7bEQWxaszp7uPNdQ/Ddv
# bg35/4ZN39F32uOj3ZYBygUjR1S4v0thmO7WCw==
# SIG # End signature block
