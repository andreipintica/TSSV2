﻿#************************************************
# TS_NetFilePSTCheck.ps1
# Version 1.0.1
# Date: 12-14-2011
# Author: v-anecho;waltere 2020-08-14, 2020-10-23
# Description:  One or more network stored PST files were detected on this machine
# Add a parameter to collect file only
#************************************************
PARAM([switch]$AlwaysCollectFile)
Import-LocalizedData -BindingVariable ScriptStrings

if ((test-path variable:psversiontable) -and ($PSVersionTable.PSVersion.Major -ge 5)) { #_# $Path | foreach { #failes on PSv4 #_# 2020-10-23 / 2021-07-23

	Write-DiagProgress -Activity $ScriptStrings.ID_NetFilePSTCheck -Status $ScriptStrings.ID_NetFilePSTCheckDesc

	$RootCauseDetected = $false
	$RootCauseName = "RC_NetworkPSTFound"
	$RootCauseSD = $ScriptStrings.ID_NetFilePSTCheckST

	#Rule ID 1842
	#-----------
	# http://sharepoint/sites/rules/Rule%20Submissions/Windows_jaklep_2011-11-09T15_59_31.xml
	#Description
	#-----------
	# One or more network stored PST files were detected on this machine
	#
	#Related KB
	#----------
	# 297019 
	#
	#Script Author
	#-------------
	# anecho


		
	#********************
	#Data gathering
	#********************
	$InformationCollected = new-object PSObject
	$HasIssue = $false 	

	$FilesToCollect = join-path $PWD.Path "$($computername)_OpenFiles.txt"

	Function get-Openfiles {	
		$collection = @()
		$isPSTFile = $false
		
		trap [Exception] 
		{
			$errorMessage = $Error[0].Exception.Message
			"           Error: Invoking resources : " + $errorMessage | WriteTo-StdOut
			$Error[0].InvocationInfo | Format-List | out-string | WriteTo-StdOut
			$Error.Clear()
		}	
		
		$adsi = [adsi] "WinNT://$computername/LANMANSERVER"
		
		if($adsi -ne $null)
		{
			$NumberOfPSTFiles = 0
			$UserNames = @()
			$Path = $adsi.PSBase.invoke("resources")
			
			if($Path)
			{
					$Path | ForEach-Object { #failes on PSv4
						
						$FilePath = $_.GetType().InvokeMember("Path", 'GetProperty', $null, $_, $null)
						$UserName = $_.GetType().InvokeMember("User", 'GetProperty', $null, $_, $null)
						$collection += New-Object PsObject -Property @{

							Id = $_.GetType().InvokeMember("Name", 'GetProperty', $null, $_, $null)
							Path = $FilePath.Replace('\\', "\")
							UserName = $UserName
							LockCount = $_.GetType().InvokeMember("LockCount", 'GetProperty', $null, $_, $null)
						}
						
						if($FilePath -like "*.PST")
						{
							$NumberOfPSTFiles++
							$UserNames += $UserName
							$isPSTFile = $true
						}
					} -ErrorAction SilentlyContinue 	#_# added EA
					if($isPSTFile -or ($AlwaysCollectFile.IsPresent))
					{
						$collection | Format-Table -AutoSize | Out-File -FilePath $FilesToCollect
						$fileDescription = "Current Open Files"
						$sectionDescription = "Server Service - Open Files"
						if (test-path $FilesToCollect) 
						{
							CollectFiles -filesToCollect $FilesToCollect -fileDescription $fileDescription -sectionDescription $sectionDescription
						}
						else
						{
							"No files found at $FilesToCollect" | WriteTo-StdOut
						}
					}
					if($isPSTFile)
					{
						$InformationCollected | Add-Member -MemberType NoteProperty -Name "Number of open PST files" -Value $NumberOfPSTFiles
						$InformationCollected | Add-Member -MemberType NoteProperty -Name "User name(s)" -Value ([string]::Join(", ", ($UserNames | Select-Object -Unique -First 10)))
						return $true
					}
					else
					{
						return $false
					}
			}
			else
			{
				return $false
			}
		}
		else
		{
			return $false
		}	
	}
		

	#********************
	#Detection Logic
	#********************
	if(-not(Test-Path $FilesToCollect))	{
		if (get-Openfiles)
		{
			$HasIssue = $true		
		}
		#********************
		#Alert Evaluation
		#********************
		if($HasIssue)
		{
			Update-DiagRootCause -id $RootCauseName -Detected $true
			Write-GenericMessage -RootCauseId $RootCauseName -PublicContentURL "http://support.microsoft.com/kb/297019" -Verbosity "Error" -InformationCollected $InformationCollected -Visibility 3 -SupportTopicsID 8125 -SolutionTitle $RootCauseSD -Component "Networking" -SDPFileReference (Split-Path $FilesToCollect -Leaf) -MessageVersion 2
		}
		else
		{	
			Update-DiagRootCause -id $RootCauseName -Detected $false
		}
	}
}


# SIG # Begin signature block
# MIInrQYJKoZIhvcNAQcCoIInnjCCJ5oCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBa7Srkw1/gqitw
# wE0Y9aowAmNltwJflGt9tuOXKn5FOKCCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGY0wghmJAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIOt7IC/Xq4B2eaDdSGAnOQxU
# gB/U9oG0P7oF8XTZMOR4MEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQCMBMDgBRU8izCtyIrkYJ7t/98PdnFv1lvQHsDDA/uRtThquCKpH5Xu
# BGTFCm4A7VpCKQGqEmTqKj/bO67vSg5UkPelvfTvW9rF1dl+OYpoMecJiCyhWV2f
# TFfInHqlg3KK8SBsj9TyHV0A9yE+q3JKT5Q8UZbfAbzL7CuyjDfNbRd62L3vnzdL
# BO17y4GuW+pNfYw4LgF+G2ncJbykvb4OljBRNckWqi8R9dSb5vI2Tx91N9h4bqP6
# pfbS2RQgyJjzs/WL7MdHHq6Bym6P9hBxfEgorKztHjx7nXcOLCi8QHU5f8keWSEb
# lY0CTJRrKasqrTIDLSTlzpnkDVQNkwNuoYIXFTCCFxEGCisGAQQBgjcDAwExghcB
# MIIW/QYJKoZIhvcNAQcCoIIW7jCCFuoCAQMxDzANBglghkgBZQMEAgEFADCCAVgG
# CyqGSIb3DQEJEAEEoIIBRwSCAUMwggE/AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIKE4TuXpHbGbfhhFWgMs+duWxJqI8BTAMx5gatpIr7IMAgZi3mrX
# 4+gYEjIwMjIwODAxMDc0MjM3LjI2WjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjowODQyLTRCRTYtQzI5QTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCEWUwggcUMIIE/KADAgECAhMzAAABh0IWZgRc8/SNAAEAAAGHMA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIx
# MTAyODE5MjczOVoXDTIzMDEyNjE5MjczOVowgdIxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MDg0Mi00
# QkU2LUMyOUExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC+aXgZYz0Do9ERCIeBkAA8
# rqf5OHqb4tjApgtpAWVldtOquh2GyeLsdUhGSoEW4byiDUpmvLTbESaZt2nz07jT
# EIhB9bwUpbug7+Vhi1QBBbaSnS4y5gQnVeRnp4eNwy6oQnALjtRqRnHcB6RqQ/4Z
# 8a4MM72RkZBF7wimKInhCSfqZsOFtGmBxQ52wPOY3PqRcbuB8h+ByzmTO4og/qc3
# i2yM+HIXnxVTRl8jQ9IL6fk5fSGxTyF5Z7elSIOvmCo/XprqQiMUkeSA09iAyK8Z
# NApyM3E1xeefKZP8lW42ztm+TU/kpZ/wbVcb8y1lnn+O6qyDRChSZBmNWHRdGS7t
# ikymS1btd8UDfL5gk4bWlXOLMHc/MldQLwxrwBTLC1S5QtaNhPnLv8TDAdaafVFP
# Q+Fin2Sal9Lochh8QFuhhS9QtbYecY1/Hrl/hSRzuSA1JBt4AfrKM7l2DoxTA9/O
# j+sF01pl8nFntGxxMHJO2XFuV9RPjrI8cJcAKJf8GFocRjh50WCn9whvtccUlu7i
# Y0MA/NGUCQiPVIa470bixuSMz1ek0xaCWPZ0L1As3/SB4EVeg0jwX4d8fDgmj6nq
# JI/yGfjeaSRYpIY6JPiEsnOhwSsWe0rmL095tdKrYG8yDNVz4EG8I3fkN8PSaiRE
# rFqba1AzTrRI5HLdLu5x6wIDAQABo4IBNjCCATIwHQYDVR0OBBYEFCJRwBa6QS1h
# gX7dYXOZkD8NpY0gMB8GA1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8G
# A1UdHwRYMFYwVKBSoFCGTmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMv
# Y3JsL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBs
# BggrBgEFBQcBAQRgMF4wXAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0
# LmNvbS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUy
# MDIwMTAoMSkuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgw
# DQYJKoZIhvcNAQELBQADggIBALmrflPZEqMAVE3/dxiOc8XO09rsp6okomcqC+JS
# P0gx8Lz8VDajHpTDJ3jRNLvMq+24yXXUUWV9aQSdw3eWqKGJICogM851W+vWgljg
# 0VAE4fMul616kecyDRQvZRcfO+MqDbhU4jNvR210/r35AjLtIOlxWH0ojQRcobZu
# iWkHKmpG20ZMN3QlCQ60x2JKloOk4fCAIw1cTzEi7jyGK5PTvmgiqccmFrfvz8Om
# 6AjQNmNhxkfVwbzgnTq5yrnKCuh32zOvX05sJkl0kunK8lYLLw9EMCRGM8mCVKZ+
# fZRHQq+ejII7OOzMDA0Kn8kmeRGnbTB4i3Ob3uI2D4VkXUn0TXp5YgHWwKvtWP1A
# Poq37PzWs5wtF/GGU7b+wrT1TD4OJCQ9u7o5ndOwO8uyvzIb1bYDzJdyCA2p3hek
# u10SR/nY4g3QaBEtJjUs0MHggpj5mPfgjAxsNuzawKKDkuLYgtYQxX/qDIvfsnvU
# 1tbtXOjt9was2d706rGAULZZfl16DHIndLHZsrDqVt/TgppedME5LPRAL5F8m7Py
# c6kh/bz5aYw+JxfaXuCz8ysLlqebIr+dt4qRo7H4BeHBgvMRM2D7UhzKCN3CdupY
# pp8t0I0p+Gxv+AzlIVuAPkBMRfVsDHBQVXEq9C/R0hECbloOMXcNmmC/LeZKiNKs
# E3/zMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0B
# AQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAG
# A1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAw
# HhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOTh
# pkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xP
# x2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ
# 3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOt
# gFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYt
# cI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXA
# hjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0S
# idb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSC
# D/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEB
# c8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh
# 8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8Fdsa
# N8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkr
# BgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q
# /y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBR
# BgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsG
# AQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAP
# BgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjE
# MFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kv
# Y3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEF
# BQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEB
# CwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnX
# wnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOw
# Bb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jf
# ZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ
# 5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+
# ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgs
# sU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6
# OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p
# /cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6
# TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784
# cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAtQwggI9
# AgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1p
# dGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjowODQyLTRCRTYtQzI5QTElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIa
# AxUAeHeTVAQoBkSGwsZgYe1//oMbg/OggYMwgYCkfjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOaReuowIhgPMjAyMjA4MDEw
# NjA0MjZaGA8yMDIyMDgwMjA2MDQyNlowdDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA
# 5pF66gIBADAHAgEAAgIePzAHAgEAAgIRLjAKAgUA5pLMagIBADA2BgorBgEEAYRZ
# CgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0G
# CSqGSIb3DQEBBQUAA4GBAIX+F9shlDQgSToqHaWx54S1MhJmmzNt8GcR66aOZY7S
# F2pMNp5+hbT5vu7m0Q+ha9PZjbpH/k9OFN4HwmaTByoIQ09mKL076hkvH5rkii7o
# IpSYX1rUH8lIxzSfOkJNl12WA0+z3qN4m4l9KtDQEYdEebERGqHUnDOqkvZfqmvl
# MYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMA
# AAGHQhZmBFzz9I0AAQAAAYcwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJ
# AzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQguH3T9suNKUWrqYVKbkxP
# zzBWwviW/LbTq7+zXxx2awcwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCDE
# LPCgE26gH3bCwLZLFmHPgdUbK8JmfBg25zOkbJqbWDCBmDCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABh0IWZgRc8/SNAAEAAAGHMCIEIMCn
# ebuXw1zsOWqJGxVztk81KwqYeF1mKU7oh/HsoSxVMA0GCSqGSIb3DQEBCwUABIIC
# ABb+/Pgv0eB6sSEdn6dEz/5cAEDzVXKQADu41d+uOdKpsmWtTDt8iwB/3FlKfvA/
# 6ozbCgbhmhsEzLRq5dVf0VCASrgww181diQIAhvI0Pv0Ioau7pi2s6Fx4Rnf8GCX
# BcV2NZFnLUldRjpogE4HW5pKZ38UBu4xzPlnj9jxCd0CSxEiWfWCA9fq34iW9jzo
# o4nq+cCEcEeD6pDUuWoDnjxGyU/L/ExEoWEGlktuTj+L2Yh39LLwML7MTrki9GC0
# n0HDWOA/NsSIxF0cn4W9bcnAaR+eBZrCEAb5ep30DaLx/QZdC755TxDOYPq4ZJBo
# VLhwrHro5hfCgDLyDAxlVCVIWZ79iM5ZBxC5AIR9aGezY4/t0ohnVVF+7lBz8awd
# /jpJh9j+4iFa5oj+C3XNemiGAPoo2r6nrxdgouH+7F7JGGp8tUeBbHwkZNNadEQQ
# KTLzU+G6EiIY1yH6gfvY3y+wvNbTeqJ1KHGMdvNS1Kq93My7IZJ23EQ5sgDsOU4f
# dYCyRC7XD3f2wXYvLprcLuvPbwVJbH0uziiAsxdlxN3iyw1X6nRj5fJR/B3b9hpD
# zTqCmlgDTI/5EIBplxkcEaW9/8qJxIdpO3L63o3MqZV13nbaR4ml+OicM4a63yhm
# 7tUUc0ftN3iIvqYVYHJxTGJue6mW1bjFAVAjFVJC8xBI
# SIG # End signature block
