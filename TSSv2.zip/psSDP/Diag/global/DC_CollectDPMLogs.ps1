﻿#************************************************
# CollectDPMLogs.ps1
# Version 2.0.0
# Date: 09-27-2011
# Author: Patrick Lewis   - patlewis@microsoft.com
# Co-author: Wilson Souza - wsouza@microsoft.com
# Description: This script collects the .errlog and .Crash logs from the DPM\Temp directory
#************************************************
Import-LocalizedData -BindingVariable LocalsCollectDPMLogs -FileName DC_CollectDPMLogs -UICulture en-us

#Main

$DPMFolder= GetDPMInstallFolder # GetDPMInstallFolder is a function from Functions.ps1
If ($null -ne $DPMFolder)
{
	$DPMRAVersion = DPMRAVersion ($DPMFolder)
}
else 
{
	$LocalsCollectDPMLogs.ID_DPM_NotInstalled | WriteTo-StdOut -ShortFormat
}

if($null -ne $DPMRAVersion)
{
	Write-DiagProgress -Activity $LocalsCollectDPMLogs.ID_DPM_COLLECT_LOGS 
	if ($DPMRAVersion -ne 2)
	{
		$DPMFolderTemp = Join-Path $DPMFolder "temp\"
	}
	else
	{
		$DPMFolderTemp = $DPMFolder
	}
	$OutputBase= "$ComputerName$Prefix" + "_DPM_Error_Logs" + ".zip"	
	CompressCollectFilesForTimePeriod -filesToCollect ($DPMFolderTemp + "*.errlog") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 7
	
	$DPMFolderConfig = Join-Path $DPMFolder "config\"
	$OutputBase = "$ComputerName$Prefix" + "_DPM_config_xml"
	CompressCollectFilesForTimePeriod -filesToCollect ($DPMFolderConfig + "*.*") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_CONFIG_FILES -Recursive -NumberOfDays 3650

	# Collecting DPMLogs folder (this folder contains DPM Setup log, rollup update logs)
	$OutputBase = "$ComputerName$Prefix" + "_DPM_Install_Logs" 
	$DPMInstallLogs = "empty"
	if ($DPMRAVersion -eq 4)
	{
		$DPMInstallLogs = ($DPMFolder | split-path -parent) + "\DPMLogs"
	}

	if ($DPMRAVersion -eq 2 -or $DPMRAVersion -eq 3)
	{
			$DPMInstallLogs = $env:SystemDrive + "\DPMLogs"
			if (!(test-path $DPMInstallLogs))
			{
				$DPMInstallLogs = $env:ALLUSERSPROFILE + "\DPMLogs"
			}
			
	}
	if (test-path $DPMInstallLogs)
	{
		CompressCollectFilesForTimePeriod -filesToCollect ($DPMInstallLogs + "\*.*") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 3650	
	}
	else
	{
		$OutputBase += ".txt"
		"DPMLogs folder wasn't found on this system" | out-file $OutputBase
	}

	# Collecting DPM Agent installation files
	$OutputBase = "$ComputerName$Prefix" + "_DPM_Agent_Install_Logs" 
	$temp = $env:windir + "\Temp"
	if (test-path ($temp + '\MSDPM*'))
	{
		CompressCollectFilesForTimePeriod -filesToCollect ($Temp + "\MSDPM*.*") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 3650	
	}
	else
	{
		$OutputBase += ".txt"
		"DPM Agent installation Logs weren't found on this system" | out-file $OutputBase
	}

	# Collect DPMUI logs from DPM 2010/2012 which resides on the user profile
	$MSDPMVersion = [System.Diagnostics.FileVersionInfo]::GetVersionInfo(($DPMFolder + 'bin\msdpm.exe')).filemajorpart.ToString() + "." + [System.Diagnostics.FileVersionInfo]::GetVersionInfo(($DPMFolder + 'bin\msdpm.exe')).FileMinorPart.ToString()
	switch ($MSDPMVersion)
	{

		'3.0'  {
					$ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft System Center Data Protection Manager 2010'
		       }

		'4.0'  {
					$ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft System Center 2012 Data Protection Manager' 
		       }

		'4.1'  {
				    $ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft System Center 2012 Service Pack 1 Data Protection Manager'
			   }

		'4.2'  {
					$ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft System Center 2012 R2 Data Protection Manager'
		 	   }

		'5.0'  {
					$ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft System Center 2016 Technical Preview 4 Data Protection Manager'
		 	   }

		'11.0' {
					$ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft Azure Backup'
			   }
	}

	$ProfileFolders = @(Get-ChildItem ((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList").ProfilesDirectory) | Where-Object { $_.Attributes -match 'Directory' -and ($_.pschildname -notmatch 'Public' -or $_.pschildname -notmatch 'Default')})

	foreach ($Profile in $Profilefolders)
	{
		$ProfileFullPath = $Profile.FullName + $ProfileRelativePath
		If ($ProfileFullPath)
		{
			$OutputBase = $ComputerName + "_DPM_UI_CLI_Settings_" + $Profile.basename + ".Logs" 
			CompressCollectFilesForTimePeriod -filesToCollect ($ProfileFullPath + "\*.errlog") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 3650	
		}
	}


	# Collect DPM Active Owner
	if ($DPMRAVersion -eq 3 -or $DPMRAVersion -eq 4)
	{
		$DPMActiveOwner = Join-Path $DPMFolder "ActiveOwner\"
		$OutputBase = $ComputerName + "_ActiveOwner" 
		CompressCollectFilesForTimePeriod -filesToCollect ($DPMActiveOwner + "\*.*") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 3650	
	}
	
	# Collect Last queries executed against DPMDB
	if ((Test-Path "HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager\DB") -eq $true)
	{		
		add-pssnapin sqlservercmdletsnapin100 -ErrorAction SilentlyContinue
		Push-Location; Import-Module SQLPS; Pop-Location
		$OutputBase = $ComputerName + "_Last_Updated_Tables" 
		$SQLServer   = (get-itemproperty HKLM:\SOFTWARE\Microsoft\"Microsoft Data Protection Manager"\DB).SqlServer
		$SQLInstance = (get-itemproperty HKLM:\SOFTWARE\Microsoft\"Microsoft Data Protection Manager"\DB).InstanceName
		$SQLDPMDB    = (get-itemproperty HKLM:\SOFTWARE\Microsoft\"Microsoft Data Protection Manager"\DB).DatabaseName
		$Query = "SELECT OBJECT_NAME(OBJECT_ID) AS DatabaseName, last_user_update
				  FROM sys.dm_db_index_usage_stats
		          WHERE database_id = DB_ID( '" + $SQLDPMDB + "')
		          ORDER BY last_user_update desc"
		invoke-sqlcmd -serverinstance ($SQLServer + "\"+ $SQLInstance) -query $Query -database $SQLDPMDB ! out-file $OutputBase 
		CompressCollectFilesForTimePeriod -filesToCollect $OutputBase -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 3650			
	}
}
		
	
# SIG # Begin signature block
# MIInmAYJKoZIhvcNAQcCoIIniTCCJ4UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBrA7K2Ju2Ljabw
# I4kRq8dcGLVe0zttPrIopS1Dcl7DyKCCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGXgwghl0AgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIIIrntAaLJ7xr8lpemc+KDtJ
# zkqeAVJyTg605xmVa8w4MEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQB7SkB/Xhi5perVQa0q0osGiyp+DhzHV3f9yBZxp1IoCa3jHfux89Po
# k7YuiT2I2+4w2iL40P8ncUJWEEVj8PqeFQKkqNxLEmiMfhgxKWq2eCrT02oAWfXS
# mzu3+j54rfwc4fm0uJdWjpGXkNBI8+vt98H0g6XJwYHSw197YqoPYoPblh385P3z
# 8X7+NNoY+kYLYILykT5orGb1y5dT/3aa5exREF+CLgYCYLwlcSKaZWjoatsKvFqI
# WQ0R/uD7GEkQAlsFI1yHqQCQ95BJ0D82HMnsL1wzM+H9b66k+gfMAw2lt1KB7L5m
# 3cly8UCiuywXZomibLXLToUrQfpHWJa5oYIXADCCFvwGCisGAQQBgjcDAwExghbs
# MIIW6AYJKoZIhvcNAQcCoIIW2TCCFtUCAQMxDzANBglghkgBZQMEAgEFADCCAVEG
# CyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIH5eRmW6UItf3BeMIiI74L9NHMbA9woSVE56PjjwWiOBAgZi1Vwy
# ANEYEzIwMjIwODAxMDczNjAyLjE4N1owBIACAfSggdCkgc0wgcoxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBB
# bWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjNFN0Et
# RTM1OS1BMjVEMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# oIIRVzCCBwwwggT0oAMCAQICEzMAAAGg6buMuw6i0XoAAQAAAaAwDQYJKoZIhvcN
# AQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjExMjAyMTkw
# NTIzWhcNMjMwMjI4MTkwNTIzWjCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9u
# czEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046M0U3QS1FMzU5LUEyNUQxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQC/2uIOaHGdAOj2YvhhI6C8iFAq7wrl/5WpPjj0fEHC
# i6Ivx/I02Jss/HVhkfGTMGttR5jRhhrJXydWDnOmzRU3B4G525T7pwkFNFBXumM/
# 98l5k0U2XiaZ+bulXHe54x6uj/6v5VGFv+0Hh1dyjGUTPaREwS7x98Te5tFHEimP
# a+AsG2mM+n9NwfQRjd1LiECbcCZFkgwbliQ/akiMr1tZmjkDbxtu2aQcXjEfDna8
# JH+wZmfdu0X7k6dJ5WGRFwzZiLOJW4QhAEpeh2c1mmbtAfBnhSPN+E5yULfpfTT2
# wX8RbH6XfAg6sZx8896xq0+gUD9mHy8ZtpdEeE1ZA0HgByDW2rJCbTAJAht71B7R
# z2pPQmg5R3+vSCri8BecSB+Z8mwYL3uOS3R6beUBJ7iE4rPS9WC1w1fZR7K44ZSm
# e2dI+O9/nhgb3MLYgm6zx3HhtLoGhGVPL+WoDkMnt93IGoO6kNBCM2X+Cs22ql2t
# PjkIRyxwxF6RsXh/QHnhKJgBzfO+e84I3TYbI0i29zATL6yHOv5sEs1zaNMih27I
# wfWg4Q7+40L7e68uC6yD8EUEpaD2s2T59NhSauTzCEnAp5YrSscc9MQVIi7g+5GA
# dC8pCv+0iRa7QIvalU+9lWgkyABU/niFHWPjyGoB4x3Kzo3tXB6aC3yZ/dTRXpJn
# aQIDAQABo4IBNjCCATIwHQYDVR0OBBYEFHK5LlDYKU6RuJFsFC9EzwthjNDoMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQAD
# ggIBADF9xgKr+N+slAmlbcEqQBlpL5PfBMqcLkS6ySeGJjG+LKX3Wov5pygrhKft
# XZ90NYWUftIZpzdYs4ehR5RlaE3eYubWlcNlwsKkcrGSDJKawbbDGfvO4h/1L13s
# g66hPib67mG96CAqRVF0c5MA1wiKjjl/5gfrbdNLHgtREQ8zCpbK4+66l1Fd0up9
# mxcOEEphhJr8U3whwFwoK+QJ/kxWogGtfDiaq6RyoFWhP8uKSLVDV+MTETHZb3p2
# OwnBWE1W6071XDKdxRkN/pAEZ15E1LJNv9iYo1l1P/RdF+IzpMLGDAf/PlVvTUw3
# VrH9uaqbYr+rRxti+bM3ab1wv9v3xRLc+wPoniSxW2p69DN4Wo96IDFZIkLR+HcW
# CiqHVwFXngkCUfdMe3xmvOIXYRkTK0P6wPLfC+Os7oeVReMj2TA1QMMkgZ+rhPO0
# 7iW7N57zABvMiHJQdHRMeK3FBgR4faEvTjUAdKRQkKFV82uE7w0UMnseJfX7ELDY
# 9T4aWx2qwEqam9l7GHX4A2Zm0nn1oaa/YxczJ7gIVERSGSOWLwEMxcFqBGPm9QSQ
# 7ogMBn5WHwkdTTkmanBb/Z2cDpxBxd1vOjyIm4BOFlLjB4pivClO2ZksWKH7qBYl
# oYa07U1O3C8jtbzGUdHyLCaVGBV8DfD5h8eOnyjraBG7PNNZMIIHcTCCBVmgAwIB
# AgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1
# WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O
# 1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZn
# hUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t
# 1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxq
# D89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmP
# frVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSW
# rAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv
# 231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zb
# r17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYcten
# IPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQc
# xWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17a
# j54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQU
# n6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEw
# QTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9E
# b2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQB
# gjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/
# MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJ
# oEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01p
# Y1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYB
# BQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9v
# Q2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3h
# LB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x
# 5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74p
# y27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1A
# oL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbC
# HcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB
# 9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNt
# yo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3
# rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcV
# v7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A24
# 5oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lw
# Y1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAs4wggI3AgEBMIH4oYHQpIHNMIHK
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxN
# aWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNT
# IEVTTjozRTdBLUUzNTktQTI1RDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAEwa4jWjacbOYU++95ydJ7hSCi5ig
# gYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0B
# AQUFAAIFAOaRpikwIhgPMjAyMjA4MDEwOTA4NTdaGA8yMDIyMDgwMjA5MDg1N1ow
# dzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA5pGmKQIBADAKAgEAAgIJDQIB/zAHAgEA
# AgIRszAKAgUA5pL3qQIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMC
# oAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAFmxTqQS
# 1GnL8Vth/nKgv4b/RqG3sp59RrUQyzGFPYYuxVaXrh+YzS6G5mjMDLjKqSlVXSNE
# 9ajLET9KStg19qIcrPtw6eLEpiXw4F/aUPr8Dr8zAiF1qzkyzMWJD2LAnCduYus6
# LmbpO7ACqK03jktAWl1TS/u0elhmMpyy1LuPMYIEDTCCBAkCAQEwgZMwfDELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAGg6buMuw6i0XoAAQAAAaAwDQYJ
# YIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkq
# hkiG9w0BCQQxIgQg9QlJHutvj6y30ZrL7Q4md+5nqM6YOy457A0fo3yTEGwwgfoG
# CyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCAvR4o8aGUEIhIt3REvsx0+svnM6Wia
# ga5SPaK4g6+00zCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# AhMzAAABoOm7jLsOotF6AAEAAAGgMCIEIFJ3ShO03qO40Nq1ZjOvnxLmy+yaJuTB
# Bgc+cRrcACrDMA0GCSqGSIb3DQEBCwUABIICAGr+ABTYrJ/e1+ZtlzmDkSlFO785
# ujzc37bqVrGhdDRTnBUqciUxMXk0GXofYsKxrytLx05Aax9fcjgkQgQRqY0+BNdh
# pcrvjz4LArtzRthzEBRh/8Z+LVKB8C73uCQgzg/S8cRx+s8Au6QVOPhABoFUS/AI
# i5fZ2Q/LenvgbcjwgIGWJGpGkUrTFv5lCEM8cvG5ZcFckUcqEirbtZvt1XaIpbBQ
# K47jjEy0wizWGfpjs0M8aN54tWfac/PbB3FF/pFbgcqw/UJ8uYnXNimARWx0HuWg
# 4ULPqokcUpUWCHXw8McCcgk60YsOUd4tI6NnnLWHE6He4rTSNCndlyXVMFiPiWrY
# TfCh0OloebBvQKVv7BfCVDFmttp4eVrQodNexBe+oWTctNbf96tTkYrWpzlUxzim
# zg8ysrc4xHmT5+P8737KrX1Au3yAxT1kkoCmYFWlZFHXQUCQABE5xRC8RIEPxCw7
# CD46SpU4K6RcHjNLxPZXhvRR+g5AFlPEG+zUUstpX7sqpetqwFd8/Mvso+ufAUIt
# mvbJ27ytE4imX8PmkyXEYRZdH3jRHmExOTOx6K1aEZaJLNnHJmF7cQIkE6jwluu1
# FzsIY+Gr2wdYVIYwPSaxHcdCBkgRhssiwkOfIL+9QqEyoFJxgmYmWmQ+Tpv5cJoG
# woLcnj7Zh7P+sa83
# SIG # End signature block
